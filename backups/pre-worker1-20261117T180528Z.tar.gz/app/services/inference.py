
import httpx

from fastapi.responses import JSONResponse, StreamingResponse

from app.config import settings


async def generate_completion(
    payload: dict,
    route_category: str,
):
    payload = payload.copy()
    payload["model"] = settings.vllm_model

    async with httpx.AsyncClient(timeout=120.0) as client:
        response = await client.post(
            f"{settings.vllm_base_url}/v1/chat/completions",
            json=payload,
        )

        response.raise_for_status()

        return JSONResponse(
            content=response.json(),
            headers={
                "X-Semantic-Category": route_category,
            },
        )


async def stream_completion(
    payload: dict,
    route_category: str,
):
    payload = payload.copy()
    payload["model"] = settings.vllm_model
    payload["stream"] = True

    timeout = httpx.Timeout(
        connect=10.0,
        read=None,
        write=30.0,
        pool=10.0,
    )

    client = httpx.AsyncClient(timeout=timeout)

    try:
        request = client.build_request(
            "POST",
            f"{settings.vllm_base_url}/v1/chat/completions",
            json=payload,
        )

        upstream = await client.send(request, stream=True)
        upstream.raise_for_status()

    except Exception:
        await client.aclose()
        raise

    async def event_stream():
        try:
            async for chunk in upstream.aiter_bytes():
                yield chunk

        finally:
            await upstream.aclose()
            await client.aclose()

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "X-Semantic-Category": route_category,
        },
    )
