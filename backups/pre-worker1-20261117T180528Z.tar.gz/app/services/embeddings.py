
import torch
import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer


class EmbeddingService:
    def __init__(self):
        self.model_name = "sentence-transformers/all-MiniLM-L6-v2"
        self.device = torch.device("cpu")

        print("Loading embedding model on CPU...")

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name
        )

        self.model = AutoModel.from_pretrained(
            self.model_name
        )

        self.model.to(self.device)
        self.model.eval()

        print("Embedding model loaded successfully.")

    def encode(self, texts: list[str]) -> torch.Tensor:
        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=256,
            return_tensors="pt",
        )

        inputs = {
            key: value.to(self.device)
            for key, value in inputs.items()
        }

        with torch.inference_mode():
            outputs = self.model(**inputs)

            token_embeddings = outputs.last_hidden_state

            attention_mask = inputs["attention_mask"]
            mask = attention_mask.unsqueeze(-1).expand(
                token_embeddings.size()
            ).float()

            summed_embeddings = torch.sum(
                token_embeddings * mask,
                dim=1,
            )

            token_counts = torch.clamp(
                mask.sum(dim=1),
                min=1e-9,
            )

            sentence_embeddings = (
                summed_embeddings / token_counts
            )

            sentence_embeddings = F.normalize(
                sentence_embeddings,
                p=2,
                dim=1,
            )

        return sentence_embeddings
