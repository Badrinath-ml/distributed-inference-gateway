from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    vllm_base_url: str
    vllm_model: str
    gateway_port: int = 8080

    class Config:
        env_file = ".env"


settings = Settings()