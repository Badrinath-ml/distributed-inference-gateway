
from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI, HTTPException, Request

from app.services.inference import (
    generate_completion,
    stream_completion,
)
from app.services.router import SemanticRouter


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing semantic router...")

    app.state.semantic_router = SemanticRouter()

    logger.info("Semantic router initialized.")

    yield

    logger.info("Gateway shutting down.")


app = FastAPI(
    title="Distributed Inference Gateway",
    lifespan=lifespan,
)


def extract_user_prompt(payload: dict) -> str:
    messages = payload.get("messages", [])

    user_messages = [
        message.get("content", "")
        for message in messages
        if message.get("role") == "user"
    ]

    # Handle ordinary text prompts.
    # For multimodal content, collect textual blocks only.
    text_parts = []

    for content in user_messages:
        if isinstance(content, str):
            text_parts.append(content)

        elif isinstance(content, list):
            for item in content:
                if (
                    isinstance(item, dict)
                    and item.get("type") == "text"
                ):
                    text_parts.append(item.get("text", ""))

    return " ".join(text_parts).strip()


@app.get("/health")
async def health():
    return {"status": "healthy"}


@app.post("/v1/chat/completions")
async def chat_completions(
    payload: dict,
    request: Request,
):
    try:
        prompt = extract_user_prompt(payload)

        if not prompt:
            raise HTTPException(
                status_code=400,
                detail="No textual user message found.",
            )

        router = request.app.state.semantic_router

        routing_result = router.route(prompt)

        category = routing_result["category"]

        logger.info(
            "Semantic routing: category=%s, score=%.4f, margin=%.4f",
            category,
            routing_result["top_score"],
            routing_result["margin"],
        )

        if payload.get("stream", False):
            return await stream_completion(
                payload,
                route_category=category,
            )

        return await generate_completion(
            payload,
            route_category=category,
        )

    except HTTPException:
        raise

    except Exception:
        logger.exception("Inference request failed")

        raise HTTPException(
            status_code=502,
            detail="Inference gateway request failed.",
        )
